package com.train.day18;

public class Main {
    public static void main(String[] args) {
        //查找money中的所有信息
        OperateTest operateTest = new OperateTest();
        operateTest.selectAllInfo();
        //模糊搜索
        operateTest.findByUserNameLike("陆");
        //降序排序根据姓名
        operateTest.findOrderByUserName();
        //显示第二页数据
        operateTest.findByUserNameLikeOrderLimit("旭",2,2);
    }
}
