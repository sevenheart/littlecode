package com.train.day18;

public class Money {
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getuId() {
        return uId;
    }

    public void setuId(String uId) {
        this.uId = uId;
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public int getuMoney() {
        return uMoney;
    }

    public void setuMoney(int uMoney) {
        this.uMoney = uMoney;
    }

    private String uId;
    private  String uName;
    private  int uMoney;

    @Override
    public String toString() {
        return "Money{" +
                "id=" + id +
                ", uId='" + uId + '\'' +
                ", uName='" + uName + '\'' +
                ", uMoney=" + uMoney +
                '}';
    }
}
