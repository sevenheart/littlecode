package com.train.day18;

import com.train.JDBC.Student;
import com.train.JDBC.StudentOperatable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class OperateTest  {

    //执行跟新删除和增加语句
   /* public void operate(String sql){
        Connection connection = JdbcUtil.getInstance().getConnection();
        PreparedStatement preparedStatement = null;
        int index;
        try {
            //创建presparedStatement对象
           index =  preparedStatement.executeUpdate();
            //preparedStatement.setString(1,);
            System.out.println("受影响行数是"+index);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }*/
    //执行查询语句,查询表中所有信息
    public void selectAllInfo(){
        List<Money> list = new ArrayList<>();
        Connection connection = JdbcUtil.getInstance().getConnection();
        PreparedStatement preparedStatement = null;
        String sql = "select * from money";
        ResultSet rs = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            rs = preparedStatement.executeQuery();
            Money money ;
            //循环取值放入money对象中，
            while (rs.next()){
                money = new Money();
                money.setId(rs.getInt(1));
                money.setuId(rs.getString(2));
                money.setuName(rs.getString("uname"));
                money.setuMoney(rs.getInt("umoney"));
                //将money对象放在list中
                list.add(money);
            }
            //遍历list读出数据
            for (Money x :list) {
                System.out.println(x.toString());
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            //关闭链接
            JdbcUtil.closeResource(rs);
            JdbcUtil.closeResource(preparedStatement);
            JdbcUtil.closeResource(connection);
        }
    }
    //根据姓名模糊查找
    public  void findByUserNameLike(String userName){
        //建立链接
        Connection connection = JdbcUtil.getInstance().getConnection();
        PreparedStatement preparedStatement = null;
        //sql模糊查询
        String sql = "select * from money where uname like ?";
        List<Money> list = new ArrayList<>();
        ResultSet rs = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            //传入模糊匹配条件
            preparedStatement.setString(1,"%"+userName+"%");
            rs = preparedStatement.executeQuery();
            Money money;
            while (rs.next()){

                money = new Money();
                money.setId(rs.getInt(1));
                money.setuId(rs.getString(2));
                money.setuName(rs.getString("uname"));
                money.setuMoney(rs.getInt("umoney"));
                //将money对象放在list中
                list.add(money);
            }
            System.out.println("匹配到的值是");
            //遍历list读出数据
            for (Money x :list) {
                System.out.println(x.toString());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            //关闭链接
            JdbcUtil.closeResource(rs);
            JdbcUtil.closeResource(preparedStatement);
            JdbcUtil.closeResource(connection);

        }

    }
    //根据用户名字段排序
    public void findOrderByUserName(){
        List<Money> list = new ArrayList<>();
        Connection connection = JdbcUtil.getInstance().getConnection();
        PreparedStatement preparedStatement = null;
        String sql = "select * from money order by uname desc";
        ResultSet rs = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            rs = preparedStatement.executeQuery();
            Money money ;
            //循环取值放入money对象中，
            while (rs.next()){
                money = new Money();
                money.setId(rs.getInt(1));
                money.setuId(rs.getString(2));
                money.setuName(rs.getString("uname"));
                money.setuMoney(rs.getInt("umoney"));
                //将money对象放在list中
                list.add(money);
            }
            //遍历list读出数据
            System.out.println("根据用户名降序后是");
            for (Money x :list) {
                System.out.println(x.toString());
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            //关闭链接
            JdbcUtil.closeResource(rs);
            JdbcUtil.closeResource(preparedStatement);
            JdbcUtil.closeResource(connection);
        }
    }
    //排序姓名（升序），然后分页获取第二页数据的操作
    public void findByUserNameLikeOrderLimit(String userName,int currPage, int pageSize){
        List<Money> list = new ArrayList<>();
        Connection connection = JdbcUtil.getInstance().getConnection();
        PreparedStatement preparedStatement = null;
        String sql = "select * from money where uname like ? order by uname  desc limit ?,?";
        ResultSet rs = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,"%"+userName+"%");
            preparedStatement.setInt(2,(currPage-1)*pageSize);
            preparedStatement.setInt(3,pageSize);
            rs = preparedStatement.executeQuery();
            Money money ;
            //循环取值放入money对象中，
            while (rs.next()){
                money = new Money();
                money.setId(rs.getInt(1));
                money.setuId(rs.getString(2));
                money.setuName(rs.getString("uname"));
                money.setuMoney(rs.getInt("umoney"));
                //将money对象放在list中
                list.add(money);
            }
            //遍历list读出数据
            System.out.println("第二页的数据是");
            for (Money x :list) {
                System.out.println(x.toString());
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            //关闭链接
            JdbcUtil.closeResource(rs);
            JdbcUtil.closeResource(preparedStatement);
            JdbcUtil.closeResource(connection);
        }
    }
}
