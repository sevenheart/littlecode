package com.train.day18;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.locks.Condition;

/**
 * 事务练习，
 * 存钱取钱
 */
public class transaction {
    public static void main(String[] args) {
        Connection connection = JdbcUtil.getInstance().getConnection();
        PreparedStatement preparedStatement = null;
        //String sql ="insert into money value(null,'005','呵呵',100)";
        String sql ="update  money set  umoney = umoney+100 where id = 1";
        try {
            //配置为不自动提交
            connection.setAutoCommit(false);
            //创建preparedStatement对象
            preparedStatement = connection.prepareStatement(sql);
            //存钱操作
            preparedStatement.executeUpdate();
            System.out.println("存完钱了");
            //取钱
            sql = "update  money set  umoney = umoney-50 where id = 1";
            preparedStatement =connection.prepareStatement(sql);
            //执行取钱操作
            preparedStatement.executeUpdate();
            //提交操作
            System.out.println("取完钱了");
            connection.commit();
            System.out.println("提交完了");
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            //释放资源
            JdbcUtil.closeResource(preparedStatement);
            JdbcUtil.closeResource(connection);

        }

    }
}
