var config = require('../../config.js');
var address = config.address;
Page({
  data: {
    userInfo: getApp().globalData.userInfo,
    hasUserInfo:false,
    imgsrc:"",
    nickName:""
  },
  onShareAppMessage() {//分享
    return {
      title: '及时帮平台',
      path: '/pages/loginbutton/loginbutton'
    }
  },
  click1(){wx.navigateTo({
    url: "/pages/allmessage/allmessage",
  })},
  click2(){wx.navigateTo({
    url: "/pages/pubRequest/pubRequest",
  })},
  click3() {
    wx.navigateTo({
      url: "/pages/Message/Message",
    })
  },
  click4() {
    wx.navigateTo({
      url: "/pages/comRequest/comRequest",
    })
  },
  showwaitmessage(){
    wx.navigateTo({
      url: '../userInfo/userInfo?userid=' + getApp().globalData.userid + "&type=waitmessage",
    })
  },
  showcompletemessage() {
    wx.navigateTo({
      url: '../userInfo/userInfo?userid=' + getApp().globalData.userid + "&type=completemessage",
    })
  },

  onShow:function(){
    this.data.reMsg = []
    this.setData({ userInfo: getApp().globalData.userInfo });
    this.selectnothanlemessage(getApp().globalData.userid);
  },
  onLoad: function (options) {
    var that = this
    wx.onSocketMessage(function (res) {
      var list = that.data.reMsg
      list.push(res.data)
      that.setData({
        reMsg: list
      })
    })
  },

  selectnothanlemessage(userid) {
    var that = this
    wx.request({
      url: address +'ws/selectnothandlemsg',
      data: {
        "userid": userid,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
      success(res) {
        that.setData({ nothandlemsg: res.data.message })
        wx.request({
          url: address +'notice/selectnothandlenotice',
          data: {
            "userid": userid,
            check: {
              "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
            }
          },
          success(res) {
            that.setData({ nothandlenotice: res.data.message })
            wx.request({
              url: address +'completemessage/selectnothandlecompletemessage',
              data: {
                "userid": userid,
                check: {
                  "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
                }
              },
              success(res) {
                that.setData({ nothandlecompletemessage: res.data.message })
                if (!(that.data.nothandlecompletemessage > 0 || that.data.nothandlenotice > 0 || that.data.nothandlemsg > 0)) {
                  wx.hideTabBarRedDot({
                    index: 2,
                  })
                }
                else {
                  wx.showTabBarRedDot({
                    index: 2,
                  })
                }
              }
            })
          }
        })

      }
    })
  },
  sendMessage: function () {
    if(this.data.reMsg.length == 0){
      wx.navigateTo({
        url: '../Message/Message',
      })
    }else{
      var rM = this.data.reMsg.join('|')
      wx.navigateTo({
        url: '../Message/Message?Msg=' + rM,
      })
    }
  },
  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
})