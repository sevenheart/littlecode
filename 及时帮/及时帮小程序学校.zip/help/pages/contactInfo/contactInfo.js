var config = require('../../config.js');
var address = config.address;
Page({
  onShow: function () {
    this.selectcontact()
  },
selectcontact(){
  var that=this;
  wx.request({
    url: address +'contact/selectcontact',
    data: {
      userid: getApp().globalData.userid,
      check: {
        "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
      }
    },
    success(res) {
      that.setData({
        contact: res.data.message[0].contact
      })
      
    }
  })
},
  onShareAppMessage() {//分享
    return {
      title: '及时帮平台',
      path: '/pages/loginbutton/loginbutton'
    }
  },
  showTopTips(e){
    var that = this;
    wx.request({
      url: address +'contact/updatecontact',
      data:{
        contact:{
          wx:e.detail.value.wx,
          qq:e.detail.value.qq,
          phonenumber:e.detail.value.phonenumber
        },
        userid:getApp().globalData.userid,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }

      },
      success(){
        wx.switchTab({
          url: '../MyInfo/MyInfo',
        })
      }
    })
   
  }
})