var config = require('../../config.js');
var address = config.address;
var utils = require('../../utils/util.js');
Page({

  onLoad: function (options) {
    var data = options.messageone;
    data=JSON.parse(data);
    if (data.userid== getApp().globalData.userid){
      this.setData({
        detailmessage: data,
        owner:true
      })
    }
    else{
      var message = {
        "userinfo": {
          nickName: getApp().globalData.userInfo.nickName,
          avatarUrl: getApp().globalData.userInfo.avatarUrl
        },
        "title": data.title,
        "sendId": getApp().globalData.userid,//自己的id
        "id": data.userid,//接收人的id
        "aState": 0,//0为未受理状态，1为已受理
        "help_id": data._id,//当前公告的——id
        "oper":"send",
        "text":data.text,
        "changetype": data.typechange,
        "address": data.location.address,
        "publishtime": utils.formatTime(new Date())
      }

    this.setData({
      detailmessage: data,
      owner:false,
      sendMsg:message
    })
    }
  },
  onShareAppMessage() {//分享
    return {
      title: '及时帮平台',
      path: '/pages/loginbutton/loginbutton'
    }
  },
  helpthem(){
    //查数据库看状态
    var that = this;
    wx.request({
      url: address +'message/selectdostatus',
      data:{
        _id:  that.data.detailmessage._id ,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
      success(res) {
        console.log("sajdfklajsdkfl" + res.data.message[0].dostatus)
        if (res.data.message[0].dostatus!="等待"){
          wx.showToast({
            title: '该帮助已有人发起援助了！',
          })
          wx.navigateTo({
            url: '../index/index',
          })
        }
        else{
          //不是正在受理，改变状态为受理中发送帮助请求
          wx.showLoading({
            title: '正在发送请求',
          })
          wx.request({
            url: address +'message/updatedostatus',
            data: {
              _id:  that.data.detailmessage._id ,
              dostatus:"正在受理",
              check: {
                "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
              }
            },
          
        })
          var msg = JSON.stringify(that.data.sendMsg)
          console.log(msg);
          wx.request({
            url: address +'ws/savemsg',
            data: {
              data: msg,
              wherestr: {
                "help_id": that.data.sendMsg.help_id,
              },
              check: {
                "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
              }
            },
            success(res) {
              var ress = JSON.stringify(res.data.message[0]);
              wx.sendSocketMessage({
                data: [ress],
              })
             wx.request({
               url: address +'notice/savenotice',
              data:{
                check: {
                  "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
                },
                data:{
                  "id": res.data.message[0].sendId,
                  "text": res.data.message[0].text,
                  "title": res.data.message[0].title,
                  "showtext":"您的请求正在受理中！",
                  "read":0,
                  "publishtime": utils.formatTime(new Date())
                }
              },
              
             })
              wx.hideLoading();
              wx.switchTab({
                url: '/pages/index/index',
              }) 
            }
          })
      }
    }})
  },
  Report(){
    var that=this;
    wx.showModal({
      title: '举报该消息吗？',
      success(res){
        console.log("举报的信息是" + that.data.detailmessage)
        if(res.confirm){
          wx.request({
            url: address +'message/Report',
            data:{
              detailmessage:that.data.detailmessage,
              check: {
                "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
              }
            }
          })
        }

      }
    })
  }
  ,
  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
  //取消发布
  cancelpublication(){
    var that=this;
    wx.request({
      url: address +'message/cancelpublication',
      data:{
        _id:that.data.detailmessage._id,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
      success(){
        wx.switchTab({
          url: '/pages/index/index',
        })
      }
    })
  },
  user(){
    wx.navigateTo({
      url: '../userInfo/userInfo?Msg=' + JSON.stringify(this.data.detailmessage) + '&owner=0',
    })
  },
})