var config = require('../../config.js');
var address = config.address;
var utils = require('../../utils/util.js');
Page({
  onLoad: function () {
    this.showmsg();
  },
  onShareAppMessage() {//分享
    return {
      title: '及时帮平台',
      path: '/pages/loginbutton/loginbutton'
    }
  },
  //msg展示方法
  showmsg() {
    var that = this;
    wx.request({
      url: address +'ws/selectmsg',
      data: {
        wherestr: {
          "id": getApp().globalData.userid
        },
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
      success(res) {
        that.setData({
          msg: res.data.message
        })
      }
    })
  },
  //detailmsg
  detailmsg(e) {
    var that = this;
    var message = e.currentTarget.dataset.message;
    wx.showModal({
      title: message.title,
      content: "该展示的联系信息是+" + message.sendId,
      confirmText: "同意",
      cancelText: "拒绝",
      success: function (res) {
        console.log(res);
        if (res.confirm) {
          that.agree(message);
          that.showmsg();
        } else {
          that.refusal(message);
          that.showmsg();
        }
      }
    });
  },
  //同意
  agree() {
    var that = this;
    wx.request({
      url: address +'notice/savenotice',
      data: {
        data: {
          "id": that.data.showMM.sendId,
          "text": that.data.showMM.text,
          "title": that.data.showMM.title,
          "showtext": "已同意",
          "read": 0,
          "userinfo": getApp().globalData.userInfo,
          "sendId": getApp().globalData.userid,
          "publishtime": utils.formatTime(new Date())
        },
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
      success() {
        //改变msg的状态让他下此点击时
        that.changemsgstatus();
        //删除完成的message
        that.deletemessages();
        //以及存入完成表中。
        that.savecompletemessage();
        //隐藏弹窗
        that.hideModal();
      }
    })
  },
  //存储到完成表中
  savecompletemessage() {
    var that = this
    wx.request({
      url: address +'completemessage/publishcompletemessage',
      data: {
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        },
        completemessage: {
          "title": that.data.showMM.title,
          "changetype": that.data.showMM.changetype,
          "address": that.data.showMM.address,
          "text": that.data.showMM.text,
          "status": "未评价",
          "publishtime": utils.formatTime(new Date()),
          "userinfo": getApp().globalData.userInfo,
          "sendId": that.data.showMM.sendId,//点我要帮助的人的id也是改变赞数的人的id
          "ownerpeopleid": that.data.showMM.id,//帮助信息所有人的id用来展示评价的id
          "evalute": 0
        },
      },
    })
  },
  //改变message的状态到完成
  deletemessages() {
   // console.log("删除的信息id是："+this.data.showMM.help_id)
    wx.request({
      url: address +'message/deletemessage',
      data: {
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        },
        _id: this.data.showMM.help_id,
      }
    })
  },
  //改变状态
  changemsgstatus() {
    var that = this;
    wx.request({
      url: address +'ws/updatemsg',
      data: {
        _id: that.data.showMM._id,
        "aState": 1,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
      success() {
        that.showmsg()
      }
    })
  },

  
  //拒绝后改变message状态到等待
  changemessagestatus(){
    wx.request({
      url: address +'message/updatedostatus',
      data: {
        _id: this.data.showMM.help_id,
        dostatus:"等待",
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      }
    })
  },
  //拒绝删除msg
  deletemsg() {
    //删除请求信息
    var that = this;
    wx.request({
      url: address +'ws/deletemsg',
      data: {
        "_id": that.data.showMM._id,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
     
    })
  },

  //拒绝
  refusal() {
    var that = this;
    wx.request({
      url: address +'notice/savenotice',
      data: {
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        },
        data: {
          "id": that.data.showMM.sendId,
          "text": that.data.showMM.text,
          "title": that.data.showMM.title,
          "showtext": "已拒绝",
          "read": 0,
          "um_id": "",
          "publishtime": utils.formatTime(new Date())
        }

      },
      success(res){
        that.changemessagestatus();
        that.deletemsg();
        that.hideModal()
        that.showmsg()
      }
    })
  },
  //跳转用户信息页
  showUser(){
    wx.navigateTo({
      url: '../userInfo/userInfo?Msg=' + JSON.stringify(this.data.showMM),
    })
  },
  //跳转用户信息页，并且显示联系信息
  showUserContact(e) {
    var message = e.currentTarget.dataset.message
    this.setData({
      showMM: message
    })
    wx.navigateTo({
      url: '../userInfo/userInfo?Msg=' + JSON.stringify(this.data.showMM) + '&owner=1',
    })
  },
  //展示请求信息操作
  showMessageModal(e) {
    var message = e.currentTarget.dataset.message
    this.setData({
      modalName: e.currentTarget.dataset.target,
      showMM: message
    })
  },
  //展示判断删除操作
  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },
  //隐藏判断删除操作
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
  // ListTouch触摸开始
  ListTouchStart(e) {
    this.setData({
      ListTouchStart: e.touches[0].pageX
    })
  },

  // ListTouch计算方向
  ListTouchMove(e) {
    this.setData({
      ListTouchDirection: e.touches[0].pageX - this.data.ListTouchStart > 0 ? 'right' : 'left'
    })
  },

  // ListTouch计算滚动
  ListTouchEnd(e) {
    if (this.data.ListTouchDirection == 'left') {
      this.setData({
        modalName: e.currentTarget.dataset.target
      })
    } else {
      this.setData({
        modalName: null
      })
    }
    this.setData({
      ListTouchDirection: null
    })
  },
})