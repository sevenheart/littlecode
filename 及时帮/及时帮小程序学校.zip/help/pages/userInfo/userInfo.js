// pages/userInfo/userInfo.js
var config = require('../../config.js');
var address = config.address;
Page({

  onLoad: function (options) {
    var sendOwner = options.owner
    var message = JSON.parse(options.Msg)
    this.setData({
      showMsg: message,
      owner: sendOwner
    })
    if(this.data.owner == 1){
      this.showContact()
    }
  },
  onShareAppMessage() {//分享
    return {
      title: '及时帮平台',
      path: '/pages/loginbutton/loginbutton'
    }
  },

  //展示联系信息
  showContact() {
    var that = this
    //查联系信息
    wx.request({
      url: address +'contact/selectcontact',
      data: {
        userid: that.data.showMsg.sendId,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
      success(res){
        that.setData({
          contact: res.data.message[0].contact
        })
      }
    })
  },

  sectionAll() {
    if (this.data.showMsg.userid == null) {
      wx.navigateTo({
        url: '../allmessage/allmessage?userid=' + this.data.showMsg.sendId,
      })
    } else {
      wx.navigateTo({
        url: '../allmessage/allmessage?userid=' + this.data.showMsg.userid,
      })
    }
  },

  sectionCom() {
    if (this.data.showMsg.userid == null) {
      wx.navigateTo({
        url: '../comRequest/comRequest?userid=' + this.data.showMsg.sendId,
      })
    } else {
      wx.navigateTo({
        url: '../comRequest/comRequest?userid=' + this.data.showMsg.userid,
      })
    }
  },
 
})