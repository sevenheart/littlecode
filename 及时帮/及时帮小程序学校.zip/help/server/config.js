module.exports = {
  port: 5757,
  expireTime: 24 * 3600,
  appid: 'wx6f48d1819c9acbcc',
  secret: '7eed88efd275de641e39e651f8422d9d',
  mongodb: {
    host: 'localhost',
    port: 3306,
    user: 'root',
    db: 'todo',
    pass: 'todo1234',
    char: 'utf8mb4'
  },

};
