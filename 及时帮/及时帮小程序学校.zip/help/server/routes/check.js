var express = require('express')
var request = require('request')
var router = express.Router()
var select = require('../sql/sql.js')


function checkfunction(check,cb){
  var skey=check.skey
  var checkuserid = check.checkuserid
  select.findcount("userskey", {"skey":skey,"userid":checkuserid}, function (results) {
    if(results==0){
      cb(false)
    }
    else{
    cb(true)
    }
})
}
module.exports = checkfunction
