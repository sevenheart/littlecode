var express = require('express');
var request = require('request');
var router = express.Router();
var sql = require('../sql/sql.js');
router.all('*', function (req, res, next) {
  var check = JSON.parse(req.query.check)
  checklogin(check, function (result) {
    if (!result) {
      res.json({
        check: false
      })
      return
    }
    next();
  })
});
router.get('/updatecontact', function (req, res, next) {
  var contact = JSON.parse(req.query.contact);
  var userid=req.query.userid;
  sql.updateone("userskey", { "userid": parseFloat(userid) }, { $set: { "contact": contact } }, function (results) {
    if (results) {
      console.log("更新用户contact成功");
    }
    else {
      console.log("更新用户contact失败了");
    }
    res.end();
  })
});

router.get('/selectcontact', function (req, res, next) {
  var userid = req.query.userid;
  sql.find("userskey", { "userid": parseFloat(userid) },function (results) {
    if (results) {
      console.log("查找用户信息成功");
    }
    else {
      console.log("查找用户信息失败了");
    }
    results = JSON.parse(results);
    res.json({ message: results });
  })
});
module.exports = router;
