var config=require('./config.js');
var address=config.address;
App({
  onLaunch: function(){
    console.log(config.address);
    var that=this;
    wx.getSystemInfo({
      success: e => {
        that.globalData.StatusBar = e.statusBarHeight;
        let custom = wx.getMenuButtonBoundingClientRect();
        that.globalData.Custom = custom;
        that.globalData.CustomBar = custom.bottom + custom.top - e.statusBarHeight;
      }
    })
    let loginFlag = wx.getStorageSync('skey');
    if (loginFlag) {
      // 检查 session_key 是否过期
      wx.checkSession({
        // session_key 有效(未过期)
        success: function () {
          //判断缓存是否存在
          wx.getStorage({
            key: 'userid',
            success:function(res){
              that.globalData.skeyLoadingComplish = true;
            },
            fail:function(res){
              that.doLogin();
            }})

        },
        fail: function () {
          // session_key过期，重新登录
          that.doLogin();
        }
    });
      if (that.userskeyReadyCallback) {
        that.userskeyReadyCallback();
      }
    } else {
      // 无skey，作为首次登录
      that.doLogin();
      if (that.userskeyReadyCallback) {
        that.userskeyReadyCallback();
      }
    }
    //获取用户位置信息
    wx.getLocation({
      type: 'gcj02',
      success: function(res) {
        that.globalData.userlocation.longitude=res.longitude;
        that.globalData.userlocation.latitude=res.latitude;
      },
      fail() {
        wx.getSetting({
          success(res) {
            var statu = res.authSetting;
            if (!statu['scope.userLocation']) {
              wx.showModal({
                title: '是否授权当前位置',
                content: '需要获取您的地理位置，请确认授权，否则配送服务将无法正常使用',
                success(tip) {
                  if (tip.confirm) {
                    wx.openSetting({
                      success(data) {
                        if (data.authSetting["scope.userLocation"] === true) {
                          wx.showToast({
                            title: '授权成功',
                            icon: 'success',
                            duration: 1000
                          })
                          //授权成功之后，再调用wx.getLocation获取地址信息
                          wx.getLocation({
                            type: 'wgs84',
                            success(res) {
                              that.globalData.userlocation.longitude = res.longitude;
                              that.globalData.userlocation.latitude = res.latitude;
                            }
                          })
                        }
                      }
                    })
                  }
                }
              })
            }
          }
        });
      }
    })
    // 获取用户头像信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: res => {
              that.globalData.userInfo.touxiang = res.userInfo.avatarUrl;
              that.globalData.userInfo.nicheng = res.userInfo.nickName;
              that.globalData.hasUserInfo=true;
            wx.getStorage({
              key: 'userid',
              success: function(res) {
                that.globalData.userid=res.data;
                wx.request({
                  url: address +'updatatouxiang',
                  data: {
                    userInfo: JSON.stringify(that.globalData.userInfo),
                    userid: res.data
                  },
                })
              },
            })
              wx.getStorage({
                key: 'skey',
                success: function (res) {
                  that.globalData.skey = res.data
                }
              })

            }
          })
        }
      } 
    })
  },
doLogin(){
  var that=this;
  wx.login({
    success(rescode) {
      if (rescode.code) {
        wx.request({
          url: address +'login',
          data: {
            code: rescode.code,
            userInfo:JSON.stringify(that.globalData.userInfo),
            json:true,
          },
          success(res){
            that.globalData.userid = res.data.useronlyid;
            that.globalData.skey = res.data.skey;
            wx.setStorage({
              key: 'userid',
              data: res.data.useronlyid,
            })
            wx.setStorage({
              key: 'skey',
              data: res.data.skey,
            }),
              that.globalData.skeyLoadingComplish = true;
          },
        })
      }
    }
  });
},
  globalData: {
    userInfo: {
      touxiang:"",
      nicheng:""
    },
    hasUserInfo: false,
    //完成登陆以及skey的更新；
    skeyLoadingComplish:false,
    userlocation:{
      longitude:"" ,
      latitude: ""
    },
    userid:null,
    skey:null
  } 
})