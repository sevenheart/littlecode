module.exports = {
  address:'https://vip666.store/',

};
