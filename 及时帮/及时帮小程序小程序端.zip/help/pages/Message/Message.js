var utils = require('../../utils/util.js');
var config = require('../../config.js');
var address = config.address;
Page({
onShow:function(){
  this.showNotices();
  this.readall()
},
  onShareAppMessage() {
    return {
      title: '及时帮平台',
      path: '/pages/loginbutton/loginbutton'
    }
  },
  //notices展示方法
  showNotices(){
    var that=this;
    wx.request({
      url: address+'notice/selectnotice',
      data:{
        wherestr:{
          "id": getApp().globalData.userid
        },
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
          }
      },
      success(res){
        that.setData({
          notices:res.data.message
        })
      }
    })
  },
 
  //全部已读
 readall(){
   wx.request({
     url: address +'notice/updatenoticestatus',
     data:{
       "id":getApp().globalData.userid,
       check: {
         "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
       }
      }
   })
  },
  //展示联系信息
  detailcon(e) {
    var message = e.currentTarget.dataset.message;
    wx.navigateTo({
      url: '../userInfo/userInfo?Msg=' + JSON.stringify(message) + '&owner=1',
    })
  },
  //删除notice方法
  deletenotice(){
    var that=this
    wx.request({
      url: address +'notice/deletenotice',
      data: {
        "_id": this.data.message_id,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        },
      },
      success() {
        that.hideModal()
        that.showNotices()
      }
    })
  },
  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target,
      message_id: e.currentTarget.dataset.message._id
    })
  },
  //隐藏判断删除操作
  hideModal(e) {
    this.setData({
      modalName: null,
      message_id: ""
    })
  },
  // ListTouch触摸开始
  ListTouchStart(e) {
    this.setData({
      ListTouchStart: e.touches[0].pageX
    })
  },

  // ListTouch计算方向
  ListTouchMove(e) {
    this.setData({
      ListTouchDirection: e.touches[0].pageX - this.data.ListTouchStart > 0 ? 'right' : 'left'
    })
  },

  // ListTouch计算滚动
  ListTouchEnd(e) {
    if (this.data.ListTouchDirection == 'left') {
      this.setData({
        modalName: e.currentTarget.dataset.target
      })
    } else {
      this.setData({
        modalName: null
      })
    }
    this.setData({
      ListTouchDirection: null
    })
  },
})