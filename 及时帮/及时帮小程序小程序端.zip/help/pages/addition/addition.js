//logs.js
var utils=require('../../utils/util.js');
var userid;
var config = require('../../config.js');
var address = config.address;
var appid = config.appid;
var secret = config.secret;
Page({
 data:{
   countries: ["借物", "学习", "提问","跑腿","其他"],
   countryIndex: 0,
   adress:"请选择地址",
   longitude: 0,
   latitude: 0,
   dostatus:"等待",
   outtime:false,
   userid: "",
   publishtime:"",
   userInfo: ""
 },
  onShareAppMessage() {
    return {
      title: '及时帮平台',
      path: '/pages/loginbutton/loginbutton'
    }
  },
  bindCountryChange: function (e) {
    this.setData({
      countryIndex: e.detail.value
    })
  },
  //地图
  ll() {
    wx.chooseLocation({
      success: this.handlechoose.bind(this)
    })
  },
  handlechoose(res) {
    if (res.address) {
      this.setData({
        adress: res.address,
        longitude: parseFloat(res.longitude),
        latitude: parseFloat(res.latitude)
      })
    }
    else {
      this.setData({
        adress: "没有选择地址哦",
        longitude: 0,
        latitude: 0
      })
    }
  },
//发布信息
  showTopTips(e){
    var that = this;
    if (this.data.adress == "请选择地址" || e.detail.value.title==""){
      wx.showToast({
        title: '请完善信息！',
        icon: 'none'
      })
    }
    else {
    wx.showLoading({
      title: '正在发布',
    })
    //添加信息
    e.detail.value.publishtime =utils.formatTime(new Date());
    //用户信息
    e.detail.value.userInfo =getApp().globalData.userInfo;
    e.detail.value.userid=getApp().globalData.userid;
    e.detail.value.dostatus="等待";
    var content=e.detail.value.title+e.detail.value.text;
      wx.request({
        url: address + 'publishmessage/publishmessage',
        data: {
          check: {
            "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
          },
          message: e.detail.value
        },
        success(res) {//成功后截取返回值给data
          if (res.data.check != false) {
            wx.hideLoading();
            wx.showToast({
              title: '发布成功',
            })
            //清空
            that.setData({
              countryIndex: 0,
              title: "",
              text: "",
              adress: "未选择地址",
              longitude: 0,
              latitude: 0,
              dostatus: "等待",
              outtime: false,
              userid: "",
              publishtime: "",
              //提交时再确定
              userInfo: ""
            })
            wx.switchTab({
              url: '/pages/index/index',
            })
          } else {
            wx.hideLoading();
            wx.showToast({
              title: '含敏感信息',
            })
            that.setData({
              countryIndex: 0,
              title: "",
              text: "",
              adress: "未选择地址",
              longitude: 0,
              latitude: 0,
              dostatus: "等待",
              outtime: false,
              userid: "",
              publishtime: "",
              userInfo: ""
            })
          }

        }
      })


   }
  }
})