var config = require('../../config.js');
var address = config.address;
Page({
  onLoad:function(options){
    if(options.userid != null){
      this.setData({
        userid: options.userid
      })
    }else{
      this.setData({
        userid: getApp().globalData.userid
      })
    }
    this.allmessage();
  },
  onShareAppMessage() {//分享
    return {
      title: '及时帮平台',
      path: '/pages/loginbutton/loginbutton'
    }
  },
//展示已发布信息
allmessage(){
  var that = this
  wx.request({
    url: address +'message/allmessage',
    data: {
      userid: that.data.userid,
      check: {
        "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
      }
    },
    success(res){
      that.setData({
        nowMessage: res.data.message
      })
    }
  })
},
  //点击帮助信息展示详细信息
  navigatordetailmessage(event) {
    var message = (event.currentTarget.dataset.message);
    wx.navigateTo({
      url: '/pages/detailmessage/detailmessage?messageone=' + JSON.stringify(message)
    })
  },
})