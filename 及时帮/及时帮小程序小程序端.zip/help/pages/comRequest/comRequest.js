var config = require('../../config.js');
var address = config.address;
Page({
  data: {
    evaluationImgUrl: "/images/ping.png",
    starCheckedImgUrl: "/images/star.png",
    starUnCheckedImgUrl: "/images/starnull.png",     // 建议内容   
    opinion: "",
    starMap:
      [
        '非常差', '差', '一般', '好', '非常好',
      ],
    evaluations: [
      {
        id: 0,
        star: 0,
        note: "",
        read:0
      }
    ]
  },
  onShareAppMessage() {//分享
    return {
      title: '及时帮平台',
      path: '/pages/loginbutton/loginbutton'
    }
  },
  //评分，选星评价
  chooseStar: function (e) {
    const index = e.currentTarget.dataset.index;
    const star = e.target.dataset.star;
    let evaluations = this.data.evaluations;
    let evaluation = evaluations[index];
    evaluation.star = star;
    evaluation.note = this.data.starMap[star - 1];
    this.setData({
      evaluations: evaluations
    })
  },
  //显示星星
  showStar: function () {
    let evaluations = this.data.evaluations;
    let evaluation = evaluations[0];
    evaluation.star = this.data.showSM.evalute;
    evaluation.read = 1;
    evaluation.note = this.data.starMap[evaluation.star - 1];
    this.setData({
      evaluations: evaluations
    })
  },

  
  onLoad: function (options) {
    if (options.userid != null) {
     //console.log("替换为：" + options.userid)
      this.setData({
        userid: options.userid,
        owner: false
      })
    } else {
      this.setData({
        userid: getApp().globalData.userid,
        owner: true
      })
    }
    this.completemessage();
  },
  completemessage() {
    var that = this
    wx.request({
      url: address +'completemessage/selectcompletemessage',
      data: {
        userid: that.data.userid,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
      success(res) {

        that.setData({
          comMessage: res.data.message
        })
      }
    })
  },
  //改变评价信息
  changeevalute(e) {
    var that = this
    wx.request({
      url: address +'completemessage/updateevalute',
      data: {
        _id: that.data.message_id,
        evalute: that.data.evaluations[0].star,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
      success(res){
        that.setData({
          modalName: null,
          message_id: "",
          evaluations: [
            {
              id: 0,
              star: 0,
              note: "",
              read:0
            }
          ]
        })
        that.completemessage()
      }
    });
    
  },
  //展示星星操作
  showStarModal(e) {
    var showStarMsg = e.currentTarget.dataset.message
    this.setData({
      modalName: e.currentTarget.dataset.target,
      showSM: showStarMsg
    })
    this.showStar()
  },
  //展示选择星星操作
  showChooseModal(e) {
    var message_id = e.currentTarget.dataset.message._id
    this.setData({
      modalName: e.currentTarget.dataset.target,
      message_id: message_id
    })
  },
  //隐藏查看星星操作
  hideStarModal(e) {
    this.setData({
      modalName: null,
      message_id: "",
      evaluations: [
        {
          id: 0,
          star: 0,
          note: "",
          read:0
        }
      ]
    })
  },
  //展示判断删除操作
  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },
  //隐藏判断删除操作
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
})