var config = require('../../config.js');
var address = config.address;
Page({
  onLoad:function(){
    this.setCategory()
    this.selectnothanlemessage(getApp().globalData.userid);
  },
  //分类显示
  setCategory(){
    this.setData({
      ColorList: [
        {
          title: '借物',
          show: '借物',
          name: 'green',
          color: '#39b54a'
        },

        {
          title: '学习',
          show:'学习',
          name: 'blue',
          color: '#0081ff'
        },

        {
          title: '提问',
          show:'提问',
          name: 'mauve',
          color: '#9c26b0'
        },
        {
          title: '跑腿',
          show: '跑腿',
          name: 'green',
          color: '#39b54a'
        },
       

       
        {
          title: '其他',
          show: '其他',
          name: 'blue',
          color:'#0081ff'
        },
        {
          title: 'all',
          show:'全部',
          name: 'cyan',
          color: '#1cbbb4'
        },

      ]
    })
  },
  //分类查找
  choosetype(event) {
    var changetype = (event.currentTarget.dataset.type);
    this.setData({
      type: changetype
    })
    this.shownearmessage();
  },

  onShow:function(){
     this.getAllMessageByUser();
  },

  data:{
    items:{},
    type: "all"
  },
  onShareAppMessage(){//分享
    return{
      title:'及时帮平台',
      path:'/pages/loginbutton/loginbutton'
    }
  },
  getAllMessageByUser: function () {
    wx.showLoading({
      title: '正在加载！',
    })
    this.shownearmessage();
    
  },
  //点击帮助信息展示详细信息
  navigatordetailmessage (event){
    var message=(event.currentTarget.dataset.message);
    wx.navigateTo({
      url: '/pages/detailmessage/detailmessage?messageone=' + JSON.stringify(message)
    })
  },

  shownearmessage() {
    var that = this;
    wx.request({
      url: address +'message/nearmessage/',
      data:{
        userlocation:getApp().globalData.userlocation,
        type: that.data.type,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
      success(res) {
      wx.hideLoading();
        that.setData({
          items: res.data.message,
        })
      }
    })
  },
//查询未处理信息
  selectnothanlemessage(userid) {
    var that = this
    wx.request({
      url: address +'ws/selectnothandlemsg',
      data: {
        "userid": userid,
        check: {
          "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
        }
      },
      success(res) {
        that.setData({ nothandlemsg: res.data.message })
        wx.request({
          url: address +'notice/selectnothandlenotice',
          data: {
            "userid": userid,
            check: {
              "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
            }
          },
          success(res) {
            that.setData({ nothandlenotice: res.data.message })
            wx.request({
              url: address +'completemessage/selectnothandlecompletemessage',
              data: {
                "userid": userid,
                check: {
                  "skey": getApp().globalData.skey, "checkuserid": getApp().globalData.userid
                }
              },
              success(res) {
                that.setData({ nothandlecompletemessage: res.data.message })
                if (that.data.nothandlecompletemessage > 0 || that.data.nothandlenotice > 0 || that.data.nothandlemsg > 0) {
                  wx.showTabBarRedDot({
                    index: 2,
                  })
                }
              }
            })
          }
        })

      }
    })
  },
})
