var config = require('../../config.js');
var address = config.address;
Page({
  onGotUserInfo(e) {
    getApp().globalData.userInfo = e.detail.userInfo;
    wx.showLoading({
      title: '正在登录',
    });
   if (!getApp().globalData.skeyLoadingComplish) {//回调确保skey已经生成，或者已经跟新。
      getApp().userskeyReadyCallback = function () {
        this.tongbu();
      }
    } else {
      this.tongbu();
    }
  },
  tongbu(){
    wx.switchTab({
      url: '/pages/index/index',
      success(res){
        getApp().globalData.hasUserInfo = true;
        wx.hideLoading();
      }
    });
  

    


  },
 


 
})